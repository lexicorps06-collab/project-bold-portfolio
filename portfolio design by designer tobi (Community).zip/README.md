
  # portfolio design by designer tobi (Community)

  This is a code bundle for portfolio design by designer tobi (Community). The original project is available at https://www.figma.com/design/GGgHprYP4xAN6k7UUDzThD/portfolio-design-by-designer-tobi--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  