import svgPaths from "./svg-xx9275ewak";

function SvgGraphic() {
  return (
    <div className="absolute left-0 size-[32px] top-0" data-name="SVG Graphic">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="SVG Graphic">
          <path d={svgPaths.pfa04680} fill="var(--fill-0, black)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function DivSize3() {
  return (
    <div className="absolute left-0 size-[32px] top-0" data-name="div.size-8">
      <SvgGraphic />
    </div>
  );
}

function DivFlex() {
  return (
    <div className="absolute h-[32px] left-[24px] top-[20px] w-[188.945px]" data-name="div.flex">
      <DivSize3 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[48px] not-italic text-[18px] text-white top-[16.25px] tracking-[-0.45px] whitespace-nowrap">
        <p className="leading-[22.5px]">Sultan Oluwatobi</p>
      </div>
    </div>
  );
}

function ButtonFlex() {
  return (
    <div className="absolute bg-[#1152d4] h-[40px] left-[38.05px] rounded-[8px] top-0 w-[100px]" data-name="button.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[51.54px] not-italic text-[14px] text-center text-white top-[20px] whitespace-nowrap">
        <p className="leading-[20px]">Resume</p>
      </div>
    </div>
  );
}

function DivFlex1() {
  return (
    <div className="absolute h-[40px] left-[212.95px] top-[16px] w-[138.055px]" data-name="div.flex">
      <ButtonFlex />
    </div>
  );
}

function HeaderFlex() {
  return (
    <div className="absolute h-[73px] left-0 top-0 w-[375px]" data-name="header.flex">
      <DivFlex />
      <DivFlex1 />
    </div>
  );
}

function SpanInlineFlex() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] h-[28px] left-0 rounded-[9999px] text-[#1152d4] top-[-23px] w-[160.148px]" data-name="span.inline-flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[19px] text-[14px] text-center top-[14px] w-[14px]">
        <p className="leading-[20px]">verified_user</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15.5px] justify-center left-[34px] text-[12px] top-[13.75px] tracking-[1.2px] w-[114.148px]">
        <p className="leading-[16px]">Dual Specialist</p>
      </div>
    </div>
  );
}

function H1TextSlate() {
  return (
    <div className="-translate-x-1/2 absolute font-['Inter:Bold',sans-serif] font-bold h-[254px] left-1/2 text-[48px] top-[30px] tracking-[-1.2px] w-[327px]" data-name="h1.text-slate-900">
      <div className="-translate-y-1/2 absolute flex flex-col h-[121px] justify-center left-0 text-white top-[46.5px] w-[327px]">
        <p className="leading-[60px]">{`UI/UX Designer &`}</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[61px] justify-center left-0 text-[#1152d4] top-[134.5px] w-[369px]">
        <p className="leading-[60px]">Cybersecurity</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[61px] justify-center left-[2px] text-white top-[196.5px] w-[299px]">
        <p className="leading-[60px]">Specialist</p>
      </div>
    </div>
  );
}

function DivFlex4() {
  return (
    <div className="absolute h-[446.25px] leading-[0] left-0 not-italic top-0 w-[327px]" data-name="div.flex">
      <SpanInlineFlex />
      <H1TextSlate />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[146.25px] justify-center left-0 text-[#94a3b8] text-[18px] top-[373.13px] w-[327px]">
        <p className="leading-[29.25px]">Merging aesthetic precision with robust digital security. I build experiences that are as safe as they are beautiful, protecting users through design.</p>
      </div>
    </div>
  );
}

function ButtonFlex1() {
  return (
    <div className="absolute bg-[#1152d4] h-[48px] left-0 rounded-[8px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0)] top-0 w-[151.781px]" data-name="button.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] left-[calc(50%+0.11px)] not-italic text-[16px] text-center text-white top-[23.75px] w-[138px]">
        <p className="leading-[24px]">View Projects</p>
      </div>
    </div>
  );
}

function ButtonFlex2() {
  return (
    <div className="absolute bg-[#1e293b] h-[48px] left-[167.78px] rounded-[8px] top-0 w-[140px]" data-name="button.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] left-[calc(50%-0.28px)] not-italic text-[16px] text-center text-white top-[23.75px] w-[115px]">
        <p className="leading-[24px]">Contact Me</p>
      </div>
    </div>
  );
}

function DivFlex5() {
  return (
    <div className="absolute h-[48px] left-0 top-[470.25px] w-[327px]" data-name="div.flex">
      <ButtonFlex1 />
      <ButtonFlex2 />
    </div>
  );
}

function DivFlex3() {
  return (
    <div className="absolute h-[518.25px] left-0 top-0 w-[327px]" data-name="div.flex">
      <DivFlex4 />
      <DivFlex5 />
    </div>
  );
}

function DivW() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.2)] left-[25.25px] rounded-[9999px] size-[48px] top-[24px]" data-name="div.w-12">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] justify-center leading-[0] left-[24px] not-italic size-[24px] text-[#1152d4] text-[24px] text-center top-[24px]">
        <p className="leading-[24px]">palette</p>
      </div>
    </div>
  );
}

function DivWFull1() {
  return (
    <div className="absolute bg-[#1e293b] h-[96px] left-[16px] rounded-[8px] top-[16px] w-[98.5px]" data-name="div.w-full">
      <DivW />
    </div>
  );
}

function DivH() {
  return <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[4px] top-0 w-[73.875px]" data-name="div.h-2" />;
}

function DivH1() {
  return <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[4px] top-[16px] w-[49.25px]" data-name="div.h-2" />;
}

function DivSpaceY() {
  return (
    <div className="absolute h-[24px] left-[16px] top-[124px] w-[98.5px]" data-name="div.space-y-2">
      <DivH />
      <DivH1 />
    </div>
  );
}

function DivRoundedXl() {
  return (
    <div className="absolute bg-[#0f172a] h-[164px] left-[24px] rounded-[12px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0)] top-[40px] w-[130.5px]" data-name="div.rounded-xl">
      <DivWFull1 />
      <DivSpaceY />
    </div>
  );
}

function DivSize() {
  return <div className="absolute bg-[#ef4444] left-0 rounded-[9999px] size-[8px] top-0" data-name="div.size-2" />;
}

function DivSize1() {
  return <div className="absolute bg-[#eab308] left-[16px] rounded-[9999px] size-[8px] top-0" data-name="div.size-2" />;
}

function DivSize2() {
  return <div className="absolute bg-[#22c55e] left-[32px] rounded-[9999px] size-[8px] top-0" data-name="div.size-2" />;
}

function DivFlex6() {
  return (
    <div className="absolute h-[8px] left-[16px] top-[16px] w-[96.5px]" data-name="div.flex">
      <DivSize />
      <DivSize1 />
      <DivSize2 />
    </div>
  );
}

function DivFontMono() {
  return (
    <div className="absolute font-['Inter:Regular',sans-serif] font-normal h-[132px] leading-[0] left-[16px] not-italic text-[10px] top-[40px] w-[96.5px]" data-name="div.font-mono">
      <div className="-translate-y-1/2 absolute flex flex-col h-[30px] justify-center left-0 text-[rgba(17,82,212,0.8)] top-[15px] w-[96.5px]">
        <p className="leading-[15px]">{`> RUN vuln_scan --all`}</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30px] justify-center left-0 text-[#4ade80] top-[49px] w-[96.5px]">
        <p className="leading-[15px]">[PASS] Port 443 Encrypted</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30px] justify-center left-0 text-[#4ade80] top-[83px] w-[96.5px]">
        <p className="leading-[15px]">[PASS] JWT Validated</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col h-[30px] justify-center left-0 text-[#facc15] top-[117px] w-[96.5px]">
        <p className="leading-[15px]">[WARN] Legacy API v1</p>
      </div>
    </div>
  );
}

function DivRoundedXl1() {
  return (
    <div className="absolute bg-[#020617] border border-[rgba(17,82,212,0.3)] border-solid h-[190px] left-[170.5px] rounded-[12px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0)] top-[95px] w-[130.5px]" data-name="div.rounded-xl">
      <DivFlex6 />
      <DivFontMono />
    </div>
  );
}

function DivAbsolute() {
  return (
    <div className="absolute left-0 size-[325px] top-0" data-name="div.absolute">
      <DivRoundedXl />
      <DivRoundedXl1 />
    </div>
  );
}

function DivAbsolute1() {
  return <div className="absolute bg-[rgba(17,82,212,0.05)] left-0 size-[325px] top-0" data-name="div.absolute" />;
}

function DivWFull() {
  return (
    <div className="absolute border border-[#1e293b] border-solid left-0 rounded-[16px] size-[327px] top-0" data-name="div.w-full">
      <DivAbsolute />
      <DivAbsolute1 />
    </div>
  );
}

function DivLgW() {
  return (
    <div className="absolute left-0 size-[327px] top-[558.25px]" data-name="div.lg:w-1/2">
      <DivWFull />
    </div>
  );
}

function DivFlex2() {
  return (
    <div className="absolute h-[885.25px] left-0 top-0 w-[327px]" data-name="div.flex">
      <DivFlex3 />
      <DivLgW />
    </div>
  );
}

function DivContainer() {
  return (
    <div className="absolute h-[885.25px] left-[24px] top-[48px] w-[327px]" data-name="div.@container">
      <DivFlex2 />
    </div>
  );
}

function DivPx() {
  return (
    <div className="absolute h-[981.25px] left-0 top-0 w-[375px]" data-name="div.px-6">
      <DivContainer />
    </div>
  );
}

function DivFlex7() {
  return (
    <div className="absolute h-[136px] leading-[0] left-[24px] not-italic top-0 w-[327px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[30px] text-white top-[18px] tracking-[-0.75px] w-[327px]">
        <p className="leading-[36px]">The Dual Identity</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[84px] justify-center left-0 text-[#94a3b8] text-[18px] top-[94px] w-[327px]">
        <p className="leading-[28px]">Bridging the gap between creative visual problem solving and technical defensive architecture.</p>
      </div>
    </div>
  );
}

function DivSize4() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] left-[32px] rounded-[12px] size-[56px] top-[32px]" data-name="div.size-14">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[36px] justify-center leading-[0] left-[28px] not-italic text-[#1152d4] text-[30px] text-center top-[28px] w-[30px]">
        <p className="leading-[36px]">draw</p>
      </div>
    </div>
  );
}

function LiFlex() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[137.664px]">
        <p className="leading-[20px]">{`Figma & Adobe Suite`}</p>
      </div>
    </div>
  );
}

function LiFlex1() {
  return (
    <div className="absolute h-[20px] left-0 top-[47px] w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[229.406px]">
        <p className="leading-[20px]">{`User Research & Persona Mapping`}</p>
      </div>
    </div>
  );
}

function LiFlex2() {
  return (
    <div className="absolute h-[20px] left-0 top-[94px] w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[159.523px]">
        <p className="leading-[20px]">Responsive Web Design</p>
      </div>
    </div>
  );
}

function UlSpaceY() {
  return (
    <div className="absolute h-[76px] leading-[0] left-[32px] not-italic text-[14px] top-[308px] w-[261px]" data-name="ul.space-y-2">
      <LiFlex />
      <LiFlex1 />
      <LiFlex2 />
    </div>
  );
}

function DivGroup() {
  return (
    <div className="absolute bg-[#1e293b] border border-[#334155] border-solid h-[446px] left-0 rounded-[16px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0)] top-0 w-[327px]" data-name="div.group">
      <DivSize4 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[32px] not-italic text-[24px] text-white top-[114px] w-[261px]">
        <p className="leading-[32px]">UI/UX Design</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[156px] justify-center leading-[0] left-[32px] not-italic text-[#94a3b8] text-[16px] top-[214px] w-[261px]">
        <p className="leading-[26px]">Specializing in high-fidelity prototyping, design systems, and user-centric workflows. I focus on creating interfaces that are not only visually stunning but also intuitive and accessible.</p>
      </div>
      <UlSpaceY />
    </div>
  );
}

function DivSize5() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] left-[32px] rounded-[12px] size-[56px] top-[32px]" data-name="div.size-14">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[36px] justify-center leading-[0] left-[28px] not-italic text-[#1152d4] text-[30px] text-center top-[28px] w-[30px]">
        <p className="leading-[36px]">encrypted</p>
      </div>
    </div>
  );
}

function LiFlex3() {
  return (
    <div className="absolute h-[20px] left-0 top-0 w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[132.406px]">
        <p className="leading-[20px]">Penetration Testing</p>
      </div>
    </div>
  );
}

function LiFlex4() {
  return (
    <div className="absolute h-[20px] left-0 top-[28px] w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[204.742px]">
        <p className="leading-[20px]">Secure Software Development</p>
      </div>
    </div>
  );
}

function LiFlex5() {
  return (
    <div className="absolute h-[20px] left-0 top-[56px] w-[261px]" data-name="li.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[7px] text-[#1152d4] text-center top-[10px] w-[14px]">
        <p className="leading-[20px]">check_circle</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[18px] justify-center left-[22px] text-[#64748b] top-[10px] w-[127.039px]">
        <p className="leading-[20px]">Threat Intelligence</p>
      </div>
    </div>
  );
}

function UlSpaceY1() {
  return (
    <div className="absolute h-[76px] leading-[0] left-[32px] not-italic text-[14px] top-[310px] w-[261px]" data-name="ul.space-y-2">
      <LiFlex3 />
      <LiFlex4 />
      <LiFlex5 />
    </div>
  );
}

function DivGroup1() {
  return (
    <div className="absolute bg-[#1e293b] border border-[#334155] border-solid h-[420px] left-0 rounded-[16px] shadow-[0px_2px_4px_0px_rgba(0,0,0,0)] top-[478px] w-[327px]" data-name="div.group">
      <DivSize5 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[32px] not-italic text-[24px] text-white top-[128px] w-[261px]">
        <p className="leading-[32px]">Cybersecurity</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[130px] justify-center leading-[0] left-[32px] not-italic text-[#94a3b8] text-[16px] top-[221px] w-[261px]">
        <p className="leading-[26px]">Protecting digital assets through rigorous vulnerability assessment, network security analysis, and the implementation of secure-by-design principles.</p>
      </div>
      <UlSpaceY1 />
    </div>
  );
}

function DivGrid() {
  return (
    <div className="absolute h-[898px] left-[24px] top-[184px] w-[327px]" data-name="div.grid">
      <DivGroup />
      <DivGroup1 />
    </div>
  );
}

function DivPx1() {
  return (
    <div className="absolute h-[1082px] left-0 top-[80px] w-[375px]" data-name="div.px-6">
      <DivFlex7 />
      <DivGrid />
    </div>
  );
}

function SectionBgSlate() {
  return (
    <div className="absolute bg-[rgba(15,23,42,0.5)] h-[1242px] left-0 top-[981.25px] w-[375px]" data-name="section.bg-slate-50">
      <DivPx1 />
    </div>
  );
}

function Div() {
  return (
    <div className="absolute h-[92px] left-0 top-0 w-[277.594px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[30px] text-white top-[18px] tracking-[-0.75px] w-[277.594px]">
        <p className="leading-[36px]">Selected Work</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[48px] justify-center left-0 text-[#64748b] text-[16px] top-[68px] w-[277.594px]">
        <p className="leading-[24px]">A mix of creative designs and security case studies.</p>
      </div>
    </div>
  );
}

function ATextPrimary() {
  return (
    <div className="absolute h-[40px] left-[277.59px] text-[#1152d4] text-[14px] top-[52px] w-[49.406px]" data-name="a.text-primary">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[38px] justify-center left-0 top-[20px] w-[31.406px]">
        <p className="leading-[20px]">View All</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[42.41px] text-center top-[20px] w-[14px]">
        <p className="leading-[20px]">arrow_forward</p>
      </div>
    </div>
  );
}

function DivFlex8() {
  return (
    <div className="absolute h-[92px] leading-[0] left-[24px] not-italic top-[80px] w-[327px]" data-name="div.flex">
      <Div />
      <ATextPrimary />
    </div>
  );
}

function DivPx2() {
  return (
    <div className="absolute h-[212px] left-0 top-[2223.25px] w-[375px]" data-name="div.px-6">
      <DivFlex8 />
    </div>
  );
}

function SpanTextWhite() {
  return (
    <div className="absolute bg-[#1152d4] h-[24px] left-[16px] rounded-[4px] top-[205.25px] w-[90.18px]" data-name="span.text-white">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15.5px] justify-center leading-[0] left-[8px] not-italic text-[12px] text-white top-[11.75px] w-[74.18px]">
        <p className="leading-[16px]">UI/UX Design</p>
      </div>
    </div>
  );
}

function DivAbsolute2() {
  return (
    <div className="absolute h-[245.25px] left-0 opacity-0 top-0 w-[327px]" data-name="div.absolute">
      <SpanTextWhite />
    </div>
  );
}

function DivRelative1() {
  return (
    <div className="absolute bg-[#1e293b] h-[245.25px] left-0 rounded-[12px] top-0 w-[327px]" data-name="div.relative">
      <div className="absolute h-[245.25px] left-0 top-0 w-[327px]" data-name="Avatar/Image">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 327 245.25">
          <ellipse cx="163.5" cy="122.625" fill="var(--fill-0, #D9D9D9)" id="Avatar/Image" rx="163.5" ry="122.625" />
        </svg>
      </div>
      <DivAbsolute2 />
    </div>
  );
}

function Div1() {
  return (
    <div className="absolute h-[68px] leading-[0] left-0 not-italic top-[261.25px] w-[327px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[18px] text-white top-[14px] w-[327px]">
        <p className="leading-[28px]">FinTech Dashboard</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40px] justify-center left-0 text-[#64748b] text-[14px] top-[48px] w-[327px]">
        <p className="leading-[20px]">User journey and high-fidelity interface for banking apps.</p>
      </div>
    </div>
  );
}

function DivFlex9() {
  return (
    <div className="absolute h-[329.25px] left-[24px] top-0 w-[327px]" data-name="div.flex">
      <DivRelative1 />
      <Div1 />
    </div>
  );
}

function SpanTextWhite1() {
  return (
    <div className="absolute bg-[#1152d4] h-[24px] left-[16px] rounded-[4px] top-[205.25px] w-[65.43px]" data-name="span.text-white">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15.5px] justify-center leading-[0] left-[8px] not-italic text-[12px] text-white top-[11.75px] w-[49.43px]">
        <p className="leading-[16px]">Security</p>
      </div>
    </div>
  );
}

function DivAbsolute3() {
  return (
    <div className="absolute h-[245.25px] left-0 opacity-0 top-0 w-[327px]" data-name="div.absolute">
      <SpanTextWhite1 />
    </div>
  );
}

function DivRelative2() {
  return (
    <div className="absolute bg-[#1e293b] h-[245.25px] left-0 rounded-[12px] top-0 w-[327px]" data-name="div.relative">
      <div className="absolute h-[245.25px] left-0 top-0 w-[327px]" data-name="Avatar/Image">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 327 245.25">
          <ellipse cx="163.5" cy="122.625" fill="var(--fill-0, #D9D9D9)" id="Avatar/Image" rx="163.5" ry="122.625" />
        </svg>
      </div>
      <DivAbsolute3 />
    </div>
  );
}

function Div2() {
  return (
    <div className="absolute h-[68px] leading-[0] left-0 not-italic top-[261.25px] w-[327px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[18px] text-white top-[14px] w-[327px]">
        <p className="leading-[28px]">Network Hardening</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40px] justify-center left-0 text-[#64748b] text-[14px] top-[48px] w-[327px]">
        <p className="leading-[20px]">Security audit and mitigation plan for cloud infrastructure.</p>
      </div>
    </div>
  );
}

function DivFlex10() {
  return (
    <div className="absolute h-[329.25px] left-[24px] top-[353.25px] w-[327px]" data-name="div.flex">
      <DivRelative2 />
      <Div2 />
    </div>
  );
}

function SpanTextWhite2() {
  return (
    <div className="absolute bg-[#1152d4] h-[24px] left-[16px] rounded-[4px] top-[205.25px] w-[90.18px]" data-name="span.text-white">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[15.5px] justify-center leading-[0] left-[8px] not-italic text-[12px] text-white top-[11.75px] w-[74.18px]">
        <p className="leading-[16px]">UI/UX Design</p>
      </div>
    </div>
  );
}

function DivAbsolute4() {
  return (
    <div className="absolute h-[245.25px] left-0 opacity-0 top-0 w-[327px]" data-name="div.absolute">
      <SpanTextWhite2 />
    </div>
  );
}

function DivRelative3() {
  return (
    <div className="absolute bg-[#1e293b] h-[245.25px] left-0 rounded-[12px] top-0 w-[327px]" data-name="div.relative">
      <div className="absolute h-[245.25px] left-0 top-0 w-[327px]" data-name="Avatar/Image">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 327 245.25">
          <ellipse cx="163.5" cy="122.625" fill="var(--fill-0, #D9D9D9)" id="Avatar/Image" rx="163.5" ry="122.625" />
        </svg>
      </div>
      <DivAbsolute4 />
    </div>
  );
}

function Div3() {
  return (
    <div className="absolute h-[68px] leading-[0] left-0 not-italic top-[261.25px] w-[327px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[18px] text-white top-[14px] w-[327px]">
        <p className="leading-[28px]">Nexus SaaS Site</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40px] justify-center left-0 text-[#64748b] text-[14px] top-[48px] w-[327px]">
        <p className="leading-[20px]">Responsive landing page with accessibility-first focus.</p>
      </div>
    </div>
  );
}

function DivFlex11() {
  return (
    <div className="absolute h-[329.25px] left-[24px] top-[706.5px] w-[327px]" data-name="div.flex">
      <DivRelative3 />
      <Div3 />
    </div>
  );
}

function DivPx3() {
  return (
    <div className="absolute h-[1115.75px] left-0 top-[2435.25px] w-[375px]" data-name="div.px-6">
      <DivFlex9 />
      <DivFlex10 />
      <DivFlex11 />
    </div>
  );
}

function MainFlex() {
  return (
    <div className="absolute h-[3551.5px] left-0 top-[73px] w-[375px]" data-name="main.flex-1">
      <DivPx />
      <SectionBgSlate />
      <DivPx2 />
      <DivPx3 />
    </div>
  );
}

function SvgGraphic1() {
  return (
    <div className="absolute left-0 size-[20px] top-0" data-name="SVG Graphic">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_357)" id="SVG Graphic">
          <path d={svgPaths.p3e7f1900} fill="var(--fill-0, black)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_357">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ATextSlate() {
  return (
    <div className="absolute h-[30.5px] left-0 top-0 w-[20px]" data-name="a.text-slate-400">
      <SvgGraphic1 />
    </div>
  );
}

function SvgGraphic2() {
  return (
    <div className="absolute left-0 size-[20px] top-0" data-name="SVG Graphic">
      <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_352)" id="SVG Graphic">
          <path d={svgPaths.p5e59f80} fill="var(--fill-0, black)" id="Vector" />
        </g>
        <defs>
          <clipPath id="clip0_1_352">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function ATextSlate1() {
  return (
    <div className="absolute h-[30.5px] left-[44px] top-0 w-[20px]" data-name="a.text-slate-400">
      <SvgGraphic2 />
    </div>
  );
}

function ATextSlate2() {
  return (
    <div className="absolute h-[30.5px] left-[88px] top-0 w-[24px]" data-name="a.text-slate-400">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] justify-center leading-[0] left-[12px] not-italic size-[24px] text-[#94a3b8] text-[24px] text-center top-[12px]">
        <p className="leading-[24px]">mail</p>
      </div>
    </div>
  );
}

function DivFlex12() {
  return (
    <div className="absolute h-[30.5px] left-[130.5px] top-[104px] w-[112px]" data-name="div.flex">
      <ATextSlate />
      <ATextSlate1 />
      <ATextSlate2 />
    </div>
  );
}

function FooterBorderT() {
  return (
    <div className="absolute border border-[#1e293b] border-solid h-[175.5px] left-0 top-[3624.5px] w-[375px]" data-name="footer.border-t">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[40px] justify-center leading-[0] left-[23px] not-italic text-[#94a3b8] text-[14px] top-[60px] w-[327px]">
        <p className="leading-[20px]">© 2024 Ogunrinde Sultan Oluwatobi. All rights reserved.</p>
      </div>
      <DivFlex12 />
    </div>
  );
}

function DivLayoutContainer() {
  return (
    <div className="absolute h-[3800px] left-0 top-0 w-[375px]" data-name="div.layout-container">
      <HeaderFlex />
      <MainFlex />
      <FooterBorderT />
    </div>
  );
}

function DivRelative() {
  return (
    <div className="absolute h-[3800px] left-0 top-[4px] w-[375px]" data-name="div.relative">
      <DivLayoutContainer />
    </div>
  );
}

function BodyBgBackgroundLight() {
  return (
    <div className="absolute bg-[#101622] h-[3800px] left-0 top-0 w-[390px]" data-name="body.bg-background-light">
      <DivRelative />
    </div>
  );
}

export default function StitchMobileDesign() {
  return (
    <div className="bg-[#101622] relative size-full" data-name="Stitch Mobile Design">
      <BodyBgBackgroundLight />
    </div>
  );
}