import svgPaths from "./svg-cih22904rk";
import imgTobi1 from "figma:asset/6ff48c6e8a80c3feff7310db4b3ffec433c6a22f.png";

function DivInlineFlex() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] border border-[rgba(17,82,212,0.2)] border-solid h-[43px] leading-[0] left-[9px] not-italic rounded-[9999px] text-[#1152d4] top-[10.5px] w-[267px]" data-name="div.inline-flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[20px] justify-center left-[19px] text-[14px] text-center top-[21px] w-[14px]">
        <p className="leading-[20px]">verified</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[18px] justify-center left-[calc(50%-95.5px)] text-[12px] top-[21px] w-[218.992px]">
        <p className="leading-[20px]">{`UI/UX & Cybersecurity Specialist`}</p>
      </div>
    </div>
  );
}

function H1Text5Xl() {
  return <div className="absolute h-[120px] left-0 top-[54px] w-[327px]" data-name="h1.text-5xl" />;
}

function ButtonPx() {
  return (
    <div className="absolute bg-[#1152d4] h-[48px] left-0 rounded-[12px] top-0 w-[164.289px]" data-name="button.px-8">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] left-[82.14px] not-italic text-[16px] text-center text-white top-[24px] w-[100.289px]">
        <p className="leading-[24px]">Download CV</p>
      </div>
    </div>
  );
}

function ButtonPx1() {
  return (
    <div className="absolute bg-[#1e293b] h-[48px] left-[180.29px] rounded-[12px] top-0 w-[131.367px]" data-name="button.px-8">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[20px] justify-center leading-[0] left-[65.68px] not-italic text-[#f1f5f9] text-[16px] text-center top-[24px] w-[67.367px]">
        <p className="leading-[24px]">My Work</p>
      </div>
    </div>
  );
}

function DivFlex1() {
  return (
    <div className="absolute h-[48px] left-0 top-[426.75px] w-[327px]" data-name="div.flex">
      <ButtonPx />
      <ButtonPx1 />
    </div>
  );
}

function DivFlex() {
  return (
    <div className="-translate-x-1/2 absolute h-[508px] left-1/2 top-[405.5px] w-[327px]" data-name="div.flex">
      <DivInlineFlex />
      <H1Text5Xl />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[204.75px] justify-center leading-[0] left-[calc(50%-155.5px)] not-italic text-[#94a3b8] text-[18px] top-[210.88px] w-[327px]">
        <p className="leading-[29.25px]">I am Ogunrinde Sultan Oluwatobi, a hybrid professional dedicated to bridging the gap between aesthetic usability and robust digital defense. I build interfaces that delight users and architectures that thwart attackers.</p>
      </div>
      <DivFlex1 />
    </div>
  );
}

function DivAbsolute() {
  return <div className="absolute left-[-4px] opacity-25 rounded-[24px] size-[335px] top-[-4px]" data-name="div.absolute" />;
}

function DivRelative1() {
  return (
    <div className="absolute left-[24px] size-[327px] top-[586.75px]" data-name="div.relative">
      <DivAbsolute />
    </div>
  );
}

function ImgWFull() {
  return (
    <div className="absolute left-0 size-[325px] top-0" data-name="img.w-full">
      <div className="absolute h-[325px] left-0 top-0 w-[319px]" data-name="tobi 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[211.57%] left-[-35.24%] max-w-none top-[-111.57%] w-[161.89%]" src={imgTobi1} />
        </div>
      </div>
    </div>
  );
}

function DivRelative2() {
  return (
    <div className="-translate-x-1/2 absolute bg-[#0f172a] border border-[#1e293b] border-solid left-1/2 rounded-[24px] size-[327px] top-[42.5px]" data-name="div.relative">
      <ImgWFull />
    </div>
  );
}

function SectionMaxW7Xl() {
  return (
    <div className="absolute h-[977.75px] left-0 top-0 w-[375px]" data-name="section.max-w-7xl">
      <DivFlex />
      <DivRelative1 />
      <DivRelative2 />
    </div>
  );
}

function DivSize() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] left-0 rounded-[12px] size-[48px] top-0" data-name="div.size-12">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] justify-center leading-[0] left-[24px] not-italic size-[24px] text-[#1152d4] text-[24px] text-center top-[24px]">
        <p className="leading-[24px]">school</p>
      </div>
    </div>
  );
}

function Div() {
  return (
    <div className="absolute h-[48px] leading-[0] left-[64px] not-italic top-0 w-[209.453px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[#f1f5f9] text-[16px] top-[12px] w-[209.453px]">
        <p className="leading-[24px]">B.Sc. Data Science</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-0 text-[#64748b] text-[14px] top-[34px] w-[209.453px]">
        <p className="leading-[20px]">University of Lagos • 2025</p>
      </div>
    </div>
  );
}

function DivFlex3() {
  return (
    <div className="absolute h-[48px] left-0 top-0 w-[327px]" data-name="div.flex">
      <DivSize />
      <Div />
    </div>
  );
}

function DivSize1() {
  return (
    <div className="absolute bg-[rgba(17,82,212,0.1)] left-0 rounded-[12px] size-[48px] top-0" data-name="div.size-12">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] justify-center leading-[0] left-[24px] not-italic size-[24px] text-[#1152d4] text-[24px] text-center top-[24px]">
        <p className="leading-[24px]">security</p>
      </div>
    </div>
  );
}

function Div1() {
  return (
    <div className="absolute h-[48px] leading-[0] left-[64px] not-italic top-0 w-[231.25px]" data-name="div">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-0 text-[#f1f5f9] text-[16px] top-[12px] w-[231.25px]">
        <p className="leading-[24px]">cybersecurity</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-0 text-[#64748b] text-[14px] top-[34px] w-[231.25px]">
        <p className="leading-[20px]">{`Cybersecurity Certification • `}</p>
      </div>
    </div>
  );
}

function DivFlex4() {
  return (
    <div className="absolute h-[48px] left-0 top-[80px] w-[327px]" data-name="div.flex">
      <DivSize1 />
      <Div1 />
    </div>
  );
}

function DivFlex2() {
  return (
    <div className="absolute h-[128px] left-0 top-[168px] w-[327px]" data-name="div.flex">
      <DivFlex3 />
      <DivFlex4 />
    </div>
  );
}

function DivMdColSpan() {
  return (
    <div className="absolute h-[296px] left-0 top-0 w-[327px]" data-name="div.md:col-span-1">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[72px] justify-center leading-[0] left-0 not-italic text-[#f1f5f9] text-[30px] top-[36px] w-[327px]">
        <p className="leading-[36px]">{`Background & Education`}</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[48px] justify-center leading-[0] left-0 not-italic text-[#94a3b8] text-[16px] top-[112px] w-[327px]">
        <p className="leading-[24px]">A journey from creative design to robust digital defense.</p>
      </div>
      <DivFlex2 />
    </div>
  );
}

function P() {
  return (
    <div className="absolute h-[263px] left-0 top-[-0.25px] w-[327px]" data-name="p">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[52px] justify-center left-0 text-[#cbd5e1] top-[29px] w-[337px]">
        <p className="leading-[29.25px]">My approach is defined by the unique intersection of</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[23px] justify-center left-0 text-[#cbd5e1] top-[72.5px] w-[42.234px]">
        <p className="leading-[29.25px]">and</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[23px] justify-center left-[42px] text-[#1152d4] top-[72.5px] w-[245px]">
        <p className="leading-[29.25px]">Defensive Security</p>
      </div>
    </div>
  );
}

function DivP1() {
  return (
    <div className="absolute bg-[#101622] border border-[#1e293b] border-solid h-[256.5px] left-0 rounded-[16px] top-[24px] w-[155.5px]" data-name="div.p-6">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[58.5px] justify-center left-[24px] text-[#1152d4] top-[53.25px] w-[105.5px]">
        <p className="leading-[29.25px]">Design Philosophy</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[120px] justify-center left-[24px] text-[#cbd5e1] top-[150.5px] w-[105.5px]">
        <p className="leading-[20px]">Human-first, accessible, and inclusive. Design should be a bridge, not a barrier.</p>
      </div>
    </div>
  );
}

function DivP2() {
  return (
    <div className="absolute bg-[#101622] border border-[#1e293b] border-solid h-[256.5px] left-[171.5px] rounded-[16px] top-[24px] w-[155.5px]" data-name="div.p-6">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[58.5px] justify-center left-[24px] text-[#1152d4] top-[53.25px] w-[105.5px]">
        <p className="leading-[29.25px]">Security Philosophy</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[140px] justify-center left-[24px] text-[#cbd5e1] top-[160.5px] w-[105.5px]">
        <p className="leading-[20px]">Defense-in-depth. Every layer of the user journey must be validated and secured.</p>
      </div>
    </div>
  );
}

function DivGrid() {
  return (
    <div className="absolute h-[280.5px] left-0 top-[574.5px] w-[327px]" data-name="div.grid">
      <DivP1 />
      <DivP2 />
    </div>
  );
}

function DivMdColSpan1() {
  return (
    <div className="-translate-x-1/2 absolute h-[855px] leading-[0] left-1/2 not-italic text-[16px] top-[360px] w-[327px]" data-name="div.md:col-span-2">
      <P />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[198.5px] justify-center left-[8px] text-[#cbd5e1] top-[197px] w-[326.867px]">
        <p className="leading-[29.25px]">. I started my career as a visual designer, obsessed with how users interact with screens. However, I soon realized that a beautiful interface is worthless if the data behind it is vulnerable.</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[263.25px] justify-center left-0 text-[#cbd5e1] top-[418.88px] w-[327px]">
        <p className="leading-[29.25px]">{`This realization drove me into the world of offensive and defensive security. I don't just design buttons; I consider how an attacker might exploit the input field those buttons trigger. I don't just build layouts; I ensure the authentication flows driving them are resilient against modern threats like CSRF and XSS.`}</p>
      </div>
      <DivGrid />
    </div>
  );
}

function DivMaxW7Xl() {
  return (
    <div className="absolute h-[1215px] left-[24px] top-[80px] w-[327px]" data-name="div.max-w-7xl">
      <DivMdColSpan />
      <DivMdColSpan1 />
    </div>
  );
}

function SectionBgSlate() {
  return (
    <div className="absolute bg-[rgba(15,23,42,0.5)] h-[1375px] left-0 top-[977.75px] w-[375px]" data-name="section.bg-slate-50">
      <DivMaxW7Xl />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[52.25px] justify-center leading-[0] left-[calc(50%-48.5px)] not-italic text-[#1152d4] text-[16px] top-[482.88px] w-[308.219px]">
        <p className="leading-[29.25px]">User-Centric Design</p>
      </div>
    </div>
  );
}

function DivTextCenter() {
  return (
    <div className="absolute h-[104px] leading-[0] left-[24px] not-italic text-center top-[96px] w-[327px]" data-name="div.text-center">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-[163.5px] text-[#f1f5f9] text-[36px] top-[20px] w-[327px]">
        <p className="leading-[40px]">Skills Matrix</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[48px] justify-center left-[163.5px] text-[#64748b] text-[16px] top-[80px] w-[327px]">
        <p className="leading-[24px]">Mastering the tools for both creation and protection.</p>
      </div>
    </div>
  );
}

function DivFlex5() {
  return (
    <div className="absolute h-[40px] left-0 top-0 w-[327px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[52px] not-italic text-[#f1f5f9] text-[24px] top-[36px] w-[212.5px]">
        <p className="leading-[32px]">{`Design & Research`}</p>
      </div>
    </div>
  );
}

function DivFlex6() {
  return (
    <div className="absolute h-[24px] leading-[0] left-0 not-italic text-[16px] top-0 w-[151.5px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center left-0 text-[#f1f5f9] top-[24px] w-[45.875px]">
        <p className="leading-[24px]">Figma</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[119.77px] text-[#1152d4] top-[24px] w-[31.734px]">
        <p className="leading-[24px]">95%</p>
      </div>
    </div>
  );
}

function DivBgPrimary() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[143.922px]" data-name="div.bg-primary" />;
}

function DivWFull() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary />
    </div>
  );
}

function DivGroup() {
  return (
    <div className="absolute h-[40px] left-0 top-0 w-[151.5px]" data-name="div.group">
      <DivFlex6 />
      <DivWFull />
    </div>
  );
}

function DivBgPrimary1() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[128.773px]" data-name="div.bg-primary" />;
}

function DivWFull1() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary1 />
    </div>
  );
}

function DivFlex7() {
  return (
    <div className="absolute h-[24px] left-[0.5px] top-[-12.25px] w-[101px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center leading-[0] left-[118.5px] not-italic text-[#1152d4] text-[16px] top-[24.25px] w-[64px]">
        <p className="leading-[24px]">80%</p>
      </div>
    </div>
  );
}

function DivGroup1() {
  return (
    <div className="absolute h-[40px] left-[175px] top-[-0.25px] w-[152px]" data-name="div.group">
      <DivWFull1 />
      <DivFlex7 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] left-0 not-italic text-[#f1f5f9] text-[16px] top-[12px] w-[161px]">
        <p className="leading-[24px]">User Research</p>
      </div>
    </div>
  );
}

function DivGroup2() {
  return <div className="absolute h-[40px] left-[175.5px] top-[64px] w-[151.5px]" data-name="div.group" />;
}

function DivGrid2() {
  return (
    <div className="absolute h-[104px] left-0 top-[72px] w-[327px]" data-name="div.grid">
      <DivGroup />
      <DivGroup1 />
      <DivGroup2 />
    </div>
  );
}

function DivSpaceY1() {
  return (
    <div className="absolute h-[176px] left-0 top-0 w-[327px]" data-name="div.space-y-8">
      <DivFlex5 />
      <DivGrid2 />
    </div>
  );
}

function DivFlex8() {
  return (
    <div className="absolute h-[40px] left-0 top-0 w-[327px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[calc(50%-109.5px)] not-italic text-[#f1f5f9] text-[24px] top-[25px] w-[218.742px]">
        <p className="leading-[32px]">Defensive Security</p>
      </div>
    </div>
  );
}

function DivFlex9() {
  return (
    <div className="absolute h-[24px] leading-[0] left-0 not-italic text-[16px] top-0 w-[151.5px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center left-0 text-[#f1f5f9] top-[12px] w-[73.219px]">
        <p className="leading-[24px]">Kali Linux</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[119.21px] text-[#1152d4] top-[24px] w-[32.289px]">
        <p className="leading-[24px]">88%</p>
      </div>
    </div>
  );
}

function DivBgPrimary2() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[133.313px]" data-name="div.bg-primary" />;
}

function DivWFull2() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary2 />
    </div>
  );
}

function DivGroup3() {
  return (
    <div className="absolute h-[40px] left-0 top-0 w-[151.5px]" data-name="div.group">
      <DivFlex9 />
      <DivWFull2 />
    </div>
  );
}

function DivFlex10() {
  return (
    <div className="absolute h-[24px] leading-[0] left-0 not-italic text-[16px] top-0 w-[151.5px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center left-0 text-[#f1f5f9] top-[12px] w-[83.539px]">
        <p className="leading-[24px]">Metasploit</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[120.54px] text-[#1152d4] top-[24px] w-[30.961px]">
        <p className="leading-[24px]">75%</p>
      </div>
    </div>
  );
}

function DivBgPrimary3() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[113.625px]" data-name="div.bg-primary" />;
}

function DivWFull3() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary3 />
    </div>
  );
}

function DivGroup4() {
  return (
    <div className="absolute h-[40px] left-[175.5px] top-0 w-[151.5px]" data-name="div.group">
      <DivFlex10 />
      <DivWFull3 />
    </div>
  );
}

function DivFlex11() {
  return (
    <div className="absolute h-[24px] leading-[0] left-0 not-italic text-[16px] top-0 w-[151.5px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center left-0 text-[#f1f5f9] top-[12px] w-[81.008px]">
        <p className="leading-[24px]">Burp Suite</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[119.53px] text-[#1152d4] top-[24px] w-[31.969px]">
        <p className="leading-[24px]">82%</p>
      </div>
    </div>
  );
}

function DivBgPrimary4() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[124.227px]" data-name="div.bg-primary" />;
}

function DivWFull4() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary4 />
    </div>
  );
}

function DivGroup5() {
  return (
    <div className="absolute h-[40px] left-0 top-[64px] w-[151.5px]" data-name="div.group">
      <DivFlex11 />
      <DivWFull4 />
    </div>
  );
}

function DivFlex12() {
  return (
    <div className="absolute h-[24px] leading-[0] left-0 not-italic text-[16px] top-0 w-[151.5px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center left-[-0.5px] text-[#f1f5f9] top-[12px] w-[110px]">
        <p className="leading-[24px]">Pen-Testing</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[118.92px] text-[#1152d4] top-[24px] w-[32.578px]">
        <p className="leading-[24px]">80%</p>
      </div>
    </div>
  );
}

function DivBgPrimary5() {
  return <div className="absolute bg-[#1152d4] h-[8px] left-0 top-0 w-[121.195px]" data-name="div.bg-primary" />;
}

function DivWFull5() {
  return (
    <div className="absolute bg-[#1e293b] h-[8px] left-0 rounded-[9999px] top-[32px] w-[151.5px]" data-name="div.w-full">
      <DivBgPrimary5 />
    </div>
  );
}

function DivGroup6() {
  return (
    <div className="absolute h-[40px] left-[175.5px] top-[64px] w-[151.5px]" data-name="div.group">
      <DivFlex12 />
      <DivWFull5 />
    </div>
  );
}

function DivGrid3() {
  return (
    <div className="absolute h-[104px] left-0 top-[72px] w-[327px]" data-name="div.grid">
      <DivGroup3 />
      <DivGroup4 />
      <DivGroup5 />
      <DivGroup6 />
    </div>
  );
}

function DivSpaceY2() {
  return (
    <div className="-translate-x-1/2 absolute h-[228px] left-[calc(50%-5px)] top-[236.75px] w-[327px]" data-name="div.space-y-8">
      <DivFlex8 />
      <DivGrid3 />
    </div>
  );
}

function DivGrid1() {
  return (
    <div className="absolute h-[400px] left-[24px] top-[264px] w-[327px]" data-name="div.grid">
      <DivSpaceY1 />
      <DivSpaceY2 />
    </div>
  );
}

function SectionMaxW7Xl1() {
  return (
    <div className="absolute h-[760px] left-0 top-[2352.75px] w-[375px]" data-name="section.max-w-7xl">
      <DivTextCenter />
      <DivGrid1 />
    </div>
  );
}

function DivSpaceY() {
  return (
    <div className="absolute h-[328px] leading-[0] left-[48px] not-italic top-[48px] w-[231px]" data-name="div.space-y-4">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[200px] justify-center left-0 text-[36px] text-white top-[100px] w-[231px]">
        <p className="leading-[40px]">Ready to build something secure and beautiful?</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[112px] justify-center left-0 opacity-90 text-[#f1f5f9] text-[18px] top-[272px] w-[231px]">
        <p className="leading-[28px]">{`Let's collaborate on your next project and ensure it stands out in both design and security.`}</p>
      </div>
    </div>
  );
}

function APx() {
  return (
    <div className="absolute bg-white h-[68px] left-[63.88px] rounded-[16px] top-[416px] w-[199.227px]" data-name="a.px-10">
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[26px] justify-center leading-[0] left-[calc(50%-63.5px)] not-italic text-[#1152d4] text-[20px] top-[33.75px] w-[126px]">
        <p className="leading-[28px]">Get In Touch</p>
      </div>
    </div>
  );
}

function DivMaxW7Xl1() {
  return (
    <div className="-translate-x-1/2 absolute bg-[#1152d4] h-[532px] left-1/2 rounded-[32px] top-0 w-[327px]" data-name="div.max-w-7xl">
      <DivSpaceY />
      <APx />
    </div>
  );
}

function SectionPx() {
  return (
    <div className="absolute h-[628px] left-0 top-[3112.75px] w-[375px]" data-name="section.px-6">
      <DivMaxW7Xl1 />
    </div>
  );
}

function MainFlex() {
  return (
    <div className="absolute h-[3740.75px] left-0 top-[79.5px] w-[375px]" data-name="main.flex-1">
      <SectionMaxW7Xl />
      <SectionBgSlate />
      <SectionMaxW7Xl1 />
      <SectionPx />
    </div>
  );
}

function DivFlex13() {
  return (
    <div className="absolute h-[24px] left-[95.22px] top-[-12px] w-[182.563px]" data-name="div.flex">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] justify-center left-[calc(50%-93.5px)] size-[24px] text-[#1152d4] text-[24px] text-center top-[11.75px]">
        <p className="leading-[24px]">security</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center left-[calc(50%-75.5px)] text-[#f1f5f9] text-[16px] top-[24px] w-[150.563px]">
        <p className="leading-[24px]">O. Sultan Oluwatobi</p>
      </div>
    </div>
  );
}

function DivFlex14() {
  return (
    <div className="absolute font-['Inter:Regular',sans-serif] font-normal h-[24px] left-[47.26px] text-[#64748b] text-[16px] top-[92px] w-[232.484px]" data-name="div.flex">
      <div className="-translate-y-1/2 absolute flex flex-col justify-center left-0 top-[12px] w-[64.141px]">
        <p className="leading-[24px]">LinkedIn</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col justify-center left-[92.14px] top-[14px] w-[52.438px]">
        <p className="leading-[24px]">GitHub</p>
      </div>
      <div className="-translate-y-1/2 absolute flex flex-col justify-center left-[156.58px] top-[11px] w-[67.906px]">
        <p className="leading-[24px]">Behance</p>
      </div>
    </div>
  );
}

function DivMaxW7Xl2() {
  return (
    <div className="absolute h-[116px] leading-[0] left-[23px] not-italic top-[48px] w-[327px]" data-name="div.max-w-7xl">
      <DivFlex13 />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal justify-center left-[calc(50%-148.5px)] text-[#64748b] text-[14px] top-[60px] w-[297.438px]">
        <p className="leading-[20px]">© 2024 Sultan Oluwatobi. All rights reserved.</p>
      </div>
      <DivFlex14 />
    </div>
  );
}

function FooterBorderT() {
  return (
    <div className="-translate-x-1/2 absolute border border-[#1e293b] border-solid h-[213px] left-1/2 top-[3777.25px] w-[375px]" data-name="footer.border-t">
      <DivMaxW7Xl2 />
    </div>
  );
}

function DivP() {
  return (
    <div className="absolute bg-[#1152d4] h-[46.5px] left-0 rounded-[8px] top-px w-[40px]" data-name="div.p-2">
      <div className="-translate-x-1/2 absolute left-1/2 overflow-clip size-[24px] top-[11px]" data-name="account_circle">
        <div className="absolute inset-[8.33%]" data-name="icon">
          <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
            <path d={svgPaths.pe3d9c80} fill="var(--fill-0, #1D1B20)" id="icon" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function DivFlex15() {
  return (
    <div className="absolute h-[46.5px] left-0 top-[2px] w-[208.602px]" data-name="div.flex">
      <DivP />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[63px] not-italic text-[#f1f5f9] text-[16px] top-[24px] tracking-[-0.5px] w-[156.602px]">
        <p className="leading-[28px]">Sultan Oluwatobi</p>
      </div>
    </div>
  );
}

function DivMdHidden() {
  return (
    <div className="absolute h-[39.5px] left-[317px] top-[8.5px] w-[30px]" data-name="div.md:hidden">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Material_Icons:Regular',sans-serif] h-[36px] justify-center leading-[0] left-[15px] not-italic text-[#f1f5f9] text-[30px] text-center top-[18px] w-[30px]">
        <p className="leading-[36px]">menu</p>
      </div>
    </div>
  );
}

function DivMaxW7Xl3() {
  return (
    <div className="absolute h-[46.5px] left-[24px] top-[16px] w-[327px]" data-name="div.max-w-7xl">
      <DivFlex15 />
      <DivMdHidden />
    </div>
  );
}

function HeaderSticky() {
  return (
    <div className="-translate-x-1/2 absolute backdrop-blur-[6px] bg-[rgba(16,22,34,0.8)] h-[79.5px] left-1/2 top-0 w-[375px]" data-name="header.sticky">
      <DivMaxW7Xl3 />
    </div>
  );
}

function DivRelative() {
  return (
    <div className="absolute h-[4008px] left-0 top-[25px] w-[375px]" data-name="div.relative">
      <MainFlex />
      <FooterBorderT />
      <HeaderSticky />
    </div>
  );
}

function BodyBgBackgroundLight() {
  return (
    <div className="absolute bg-[#101622] h-[4033px] left-0 top-0 w-[390px]" data-name="body.bg-background-light">
      <DivRelative />
    </div>
  );
}

export default function AboutMe() {
  return (
    <div className="bg-[#101622] relative size-full" data-name="about me">
      <BodyBgBackgroundLight />
    </div>
  );
}