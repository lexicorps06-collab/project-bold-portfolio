import { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'motion/react';
import { toast, Toaster } from 'sonner';
import imgTobi1 from "figma:asset/6ff48c6e8a80c3feff7310db4b3ffec433c6a22f.png";
import svgPathsLogo from "../imports/svg-bnoawmx8zi";
import { Menu, X } from 'lucide-react';

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'projects', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="bg-[#101622] min-h-screen text-white relative overflow-hidden">
      <Toaster position="top-center" theme="dark" richColors />

      {/* Animated Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute w-[500px] h-[500px] bg-[#1152d4] rounded-full blur-[150px] opacity-20"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ top: '-10%', left: '-10%' }}
        />
        <motion.div
          className="absolute w-[400px] h-[400px] bg-[#1152d4] rounded-full blur-[150px] opacity-10"
          animate={{
            x: [0, -100, 0],
            y: [0, 100, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ bottom: '10%', right: '-5%' }}
        />
      </div>

      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-[#1152d4] z-50 origin-left"
        style={{ scaleX: scrollYProgress }}
      />

      {/* Header */}
      <Header
        isMenuOpen={isMenuOpen}
        setIsMenuOpen={setIsMenuOpen}
        scrollToSection={scrollToSection}
        activeSection={activeSection}
      />

      {/* Mobile Menu */}
      <MobileMenu
        isMenuOpen={isMenuOpen}
        scrollToSection={scrollToSection}
        activeSection={activeSection}
      />

      {/* Main Content */}
      <main className="relative z-10">
        <HeroSection opacity={opacity} scrollToSection={scrollToSection} />
        <AboutSection />
        <SkillsSection />
        <ProjectsSection />
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer scrollToSection={scrollToSection} />
    </div>
  );
}

function Header({ isMenuOpen, setIsMenuOpen, scrollToSection, activeSection }: any) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        scrolled ? 'backdrop-blur-[12px] bg-[rgba(16,22,34,0.9)] shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-[375px] mx-auto px-6 py-4 flex items-center justify-between">
        <motion.div
          className="flex items-center gap-3 cursor-pointer"
          onClick={() => scrollToSection('home')}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <div className="w-8 h-8 relative">
            <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
              <path d={svgPathsLogo.pfa04680} fill="#1152d4" />
            </svg>
          </div>
          <span className="font-bold text-lg tracking-tight">Sultan Oluwatobi</span>
        </motion.div>

        <div className="flex items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => window.open('#', '_blank')}
            className="bg-[#1152d4] text-white px-6 py-2 rounded-lg font-bold text-sm hover:bg-[#0d3fa8] transition-colors"
          >
            Resume
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="text-white p-2"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>
      </div>
    </motion.header>
  );
}

function MobileMenu({ isMenuOpen, scrollToSection, activeSection }: any) {
  const menuItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'skills', label: 'Skills' },
    { id: 'projects', label: 'Projects' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <AnimatePresence>
      {isMenuOpen && (
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="fixed top-[73px] right-0 bottom-0 w-[280px] bg-[#0f172a] border-l border-[#1e293b] z-50 shadow-2xl"
        >
          <nav className="p-6 space-y-2">
            {menuItems.map((item, index) => (
              <motion.button
                key={item.id}
                initial={{ x: 50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => scrollToSection(item.id)}
                className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all ${
                  activeSection === item.id
                    ? 'bg-[#1152d4] text-white'
                    : 'text-[#94a3b8] hover:bg-[#1e293b] hover:text-white'
                }`}
              >
                {item.label}
              </motion.button>
            ))}
          </nav>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function HeroSection({ opacity, scrollToSection }: any) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false });

  return (
    <section id="home" ref={ref} className="min-h-screen pt-[120px] px-6 relative">
      <div className="max-w-[375px] mx-auto">
        {/* Badge */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 bg-[rgba(17,82,212,0.1)] border border-[rgba(17,82,212,0.2)] px-4 py-2 rounded-full mb-8"
        >
          <span className="material-icons text-[#1152d4] text-sm">verified</span>
          <span className="text-[#1152d4] font-bold text-xs tracking-wide">Dual Specialist</span>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-5xl font-bold leading-tight mb-6 tracking-tight"
        >
          UI/UX Designer &<br />
          <span className="text-[#1152d4]">Cybersecurity</span><br />
          Specialist
        </motion.h1>

        {/* Description */}
        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-[#94a3b8] text-lg leading-relaxed mb-8"
        >
          Merging aesthetic precision with robust digital security. I build experiences that are as safe as they are beautiful, protecting users through design.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex gap-4 mb-12"
        >
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 25px rgba(17, 82, 212, 0.5)' }}
            whileTap={{ scale: 0.95 }}
            onClick={() => scrollToSection('projects')}
            className="flex-1 bg-[#1152d4] text-white py-4 rounded-lg font-bold shadow-lg"
          >
            View Projects
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => scrollToSection('contact')}
            className="flex-1 bg-[#1e293b] text-white py-4 rounded-lg font-bold"
          >
            Contact Me
          </motion.button>
        </motion.div>

        {/* Hero Image */}
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={isInView ? { scale: 1, opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="relative"
        >
          <motion.div
            animate={{
              rotate: [0, 5, 0, -5, 0],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: "easeInOut"
            }}
            className="bg-[#0f172a] border border-[#1e293b] rounded-3xl overflow-hidden"
          >
            <img
              src={imgTobi1}
              alt="Sultan Oluwatobi"
              className="w-full h-auto object-cover"
            />
          </motion.div>

          {/* Floating Cards */}
          <FloatingCard
            delay={1}
            className="absolute -left-4 top-10 bg-[#0f172a] border border-[#1e293b] rounded-xl p-4 w-32 shadow-2xl"
          >
            <div className="bg-[rgba(17,82,212,0.2)] w-12 h-12 rounded-full flex items-center justify-center mb-2">
              <span className="material-icons text-[#1152d4]">palette</span>
            </div>
            <div className="space-y-2">
              <div className="h-2 bg-[#1e293b] rounded w-3/4"></div>
              <div className="h-2 bg-[#1e293b] rounded w-1/2"></div>
            </div>
          </FloatingCard>

          <FloatingCard
            delay={1.5}
            className="absolute -right-4 bottom-20 bg-[#020617] border border-[rgba(17,82,212,0.3)] rounded-xl p-4 w-32 shadow-2xl"
          >
            <div className="flex gap-2 mb-2">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            </div>
            <div className="font-mono text-[10px] space-y-1">
              <div className="text-[rgba(17,82,212,0.8)]">&gt; RUN scan</div>
              <div className="text-green-400">[PASS] Secured</div>
            </div>
          </FloatingCard>
        </motion.div>
      </div>
    </section>
  );
}

function FloatingCard({ delay, className, children }: any) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0, scale: 0.8 }}
      animate={{
        y: [0, -10, 0],
        opacity: 1,
        scale: 1
      }}
      transition={{
        y: {
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        },
        opacity: { duration: 0.6, delay },
        scale: { duration: 0.6, delay }
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, margin: "-100px" });

  return (
    <section id="about" ref={ref} className="min-h-screen py-20 px-6 bg-[rgba(15,23,42,0.5)]">
      <div className="max-w-[375px] mx-auto">
        {/* Background & Education */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-16"
        >
          <h2 className="text-3xl font-bold mb-4">Background & Education</h2>
          <p className="text-[#94a3b8] mb-8">A journey from creative design to robust digital defense.</p>

          <div className="space-y-6">
            <EducationCard
              icon="school"
              title="B.Sc. Data Science"
              subtitle="University of Lagos • 2025"
              delay={0.2}
            />
            <EducationCard
              icon="security"
              title="Cybersecurity"
              subtitle="Cybersecurity Certification"
              delay={0.4}
            />
          </div>
        </motion.div>

        {/* Philosophy */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mb-12"
        >
          <p className="text-[#cbd5e1] text-lg leading-relaxed mb-4">
            My approach is defined by the unique intersection of{' '}
            <span className="font-bold text-[#1152d4]">User-Centric Design</span> and{' '}
            <span className="font-bold text-[#1152d4]">Defensive Security</span>.
          </p>

          <p className="text-[#cbd5e1] text-lg leading-relaxed mb-8">
            I started my career as a visual designer, obsessed with how users interact with screens.
            However, I soon realized that a beautiful interface is worthless if the data behind it is vulnerable.
          </p>

          <p className="text-[#cbd5e1] text-lg leading-relaxed mb-8">
            This realization drove me into the world of offensive and defensive security. I don't just design buttons;
            I consider how an attacker might exploit the input field those buttons trigger.
          </p>
        </motion.div>

        {/* Philosophy Cards */}
        <div className="grid grid-cols-2 gap-4">
          <PhilosophyCard
            title="Design Philosophy"
            description="Human-first, accessible, and inclusive. Design should be a bridge, not a barrier."
            delay={0.8}
          />
          <PhilosophyCard
            title="Security Philosophy"
            description="Defense-in-depth. Every layer of the user journey must be validated and secured."
            delay={1}
          />
        </div>
      </div>
    </section>
  );
}

function EducationCard({ icon, title, subtitle, delay }: any) {
  return (
    <motion.div
      initial={{ x: -50, opacity: 0 }}
      whileInView={{ x: 0, opacity: 1 }}
      viewport={{ once: false }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ scale: 1.02, x: 10 }}
      className="flex items-center gap-4 cursor-pointer"
    >
      <div className="bg-[rgba(17,82,212,0.1)] w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0">
        <span className="material-icons text-[#1152d4] text-2xl">{icon}</span>
      </div>
      <div>
        <h3 className="text-white font-bold">{title}</h3>
        <p className="text-[#64748b] text-sm">{subtitle}</p>
      </div>
    </motion.div>
  );
}

function PhilosophyCard({ title, description, delay }: any) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: false }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -10, boxShadow: '0 20px 40px rgba(17, 82, 212, 0.2)' }}
      className="bg-[#101622] border border-[#1e293b] rounded-2xl p-6 cursor-pointer"
    >
      <h3 className="text-[#1152d4] font-bold text-xl mb-4 leading-snug">{title}</h3>
      <p className="text-[#cbd5e1] text-sm leading-relaxed">{description}</p>
    </motion.div>
  );
}

function SkillsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, margin: "-100px" });

  return (
    <section id="skills" ref={ref} className="min-h-screen py-20 px-6">
      <div className="max-w-[375px] mx-auto">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4">Skills Matrix</h2>
          <p className="text-[#64748b]">Mastering the tools for both creation and protection.</p>
        </motion.div>

        {/* Design Skills */}
        <SkillCategory
          title="Design & Research"
          skills={[
            { name: 'Figma', level: 95 },
            { name: 'User Research', level: 80 },
          ]}
          delay={0.2}
        />

        {/* Security Skills */}
        <SkillCategory
          title="Defensive Security"
          skills={[
            { name: 'Kali Linux', level: 88 },
            { name: 'Metasploit', level: 75 },
            { name: 'Burp Suite', level: 82 },
            { name: 'Pen-Testing', level: 80 },
          ]}
          delay={0.4}
        />
      </div>
    </section>
  );
}

function SkillCategory({ title, skills, delay }: any) {
  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: false }}
      transition={{ duration: 0.6, delay }}
      className="mb-16"
    >
      <h3 className="text-2xl font-bold mb-8 flex items-center gap-2">
        <span className="material-icons text-[#1152d4]">star</span>
        {title}
      </h3>

      <div className="grid grid-cols-2 gap-6">
        {skills.map((skill: any, index: number) => (
          <SkillBar key={skill.name} skill={skill} delay={delay + index * 0.1} />
        ))}
      </div>
    </motion.div>
  );
}

function SkillBar({ skill, delay }: any) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      whileInView={{ scale: 1, opacity: 1 }}
      viewport={{ once: false }}
      transition={{ duration: 0.4, delay }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="cursor-pointer"
    >
      <div className="flex justify-between items-center mb-2">
        <span className="text-[#f1f5f9] font-medium text-sm">{skill.name}</span>
        <motion.span
          animate={{ scale: isHovered ? 1.2 : 1 }}
          className="text-[#1152d4] font-normal text-sm"
        >
          {skill.level}%
        </motion.span>
      </div>
      <div className="bg-[#1e293b] h-2 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          whileInView={{ width: `${skill.level}%` }}
          viewport={{ once: false }}
          transition={{ duration: 1, delay: delay + 0.2, ease: "easeOut" }}
          className="bg-[#1152d4] h-full rounded-full"
          style={{
            boxShadow: isHovered ? '0 0 20px rgba(17, 82, 212, 0.8)' : 'none'
          }}
        />
      </div>
    </motion.div>
  );
}

function ProjectsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, margin: "-100px" });

  const projects = [
    {
      title: 'FinTech Dashboard',
      description: 'User journey and high-fidelity interface for banking apps.',
      category: 'UI/UX Design',
      gradient: 'from-blue-500 to-purple-600'
    },
    {
      title: 'Network Hardening',
      description: 'Security audit and mitigation plan for cloud infrastructure.',
      category: 'Security',
      gradient: 'from-green-500 to-teal-600'
    },
    {
      title: 'Nexus SaaS Site',
      description: 'Responsive landing page with accessibility-first focus.',
      category: 'UI/UX Design',
      gradient: 'from-orange-500 to-red-600'
    },
  ];

  return (
    <section id="projects" ref={ref} className="min-h-screen py-20 px-6">
      <div className="max-w-[375px] mx-auto">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="flex justify-between items-end mb-12"
        >
          <div>
            <h2 className="text-3xl font-bold mb-2">Selected Work</h2>
            <p className="text-[#64748b]">A mix of creative designs and security case studies.</p>
          </div>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="text-[#1152d4] font-bold text-sm flex items-center gap-1"
          >
            View All
            <span className="material-icons text-sm">arrow_forward</span>
          </motion.button>
        </motion.div>

        <div className="space-y-8">
          {projects.map((project, index) => (
            <ProjectCard key={project.title} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ProjectCard({ project, index }: any) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      whileInView={{ y: 0, opacity: 1 }}
      viewport={{ once: false, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.2 }}
      whileHover={{ y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      className="cursor-pointer group"
    >
      <motion.div
        className="relative bg-[#1e293b] rounded-2xl overflow-hidden mb-4"
        style={{ aspectRatio: '327/245' }}
      >
        {/* Gradient Placeholder */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-30`}
          animate={{
            scale: isHovered ? 1.1 : 1,
            opacity: isHovered ? 0.5 : 0.3
          }}
          transition={{ duration: 0.4 }}
        />

        {/* Category Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{
            opacity: isHovered ? 1 : 0,
            y: isHovered ? 0 : 20
          }}
          transition={{ duration: 0.3 }}
          className="absolute bottom-4 left-4 bg-[#1152d4] text-white px-3 py-1 rounded text-xs font-bold"
        >
          {project.category}
        </motion.div>

        {/* Hover Overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: isHovered ? 1 : 0 }}
          className="absolute inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: isHovered ? 1 : 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="bg-white text-[#1152d4] px-6 py-3 rounded-lg font-bold"
          >
            View Project
          </motion.div>
        </motion.div>
      </motion.div>

      <h3 className="text-xl font-bold mb-2 group-hover:text-[#1152d4] transition-colors">
        {project.title}
      </h3>
      <p className="text-[#64748b] text-sm">{project.description}</p>
    </motion.div>
  );
}

function ContactSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: false, margin: "-100px" });
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    project: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));

    toast.success('Message sent successfully! I\'ll get back to you soon.');
    setFormData({ name: '', email: '', project: '', message: '' });
    setIsSubmitting(false);
  };

  const handleChange = (e: any) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section id="contact" ref={ref} className="min-h-screen py-20 px-6">
      <div className="max-w-[375px] mx-auto">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={isInView ? { scale: 1, opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="bg-[#1152d4] rounded-[32px] p-12 relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-40 h-40 bg-white rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-white rounded-full blur-3xl"></div>
          </div>

          <div className="relative z-10">
            <motion.h2
              initial={{ y: 30, opacity: 0 }}
              animate={isInView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-4xl font-bold text-white mb-6 leading-tight"
            >
              Ready to build something secure and beautiful?
            </motion.h2>

            <motion.p
              initial={{ y: 30, opacity: 0 }}
              animate={isInView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-white/90 text-lg mb-8 leading-relaxed"
            >
              Let's collaborate on your next project and ensure it stands out in both design and security.
            </motion.p>

            <motion.form
              initial={{ y: 30, opacity: 0 }}
              animate={isInView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.6 }}
              onSubmit={handleSubmit}
              className="space-y-4"
            >
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Full name"
                required
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all"
              />

              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Email address"
                required
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all"
              />

              <input
                type="text"
                name="project"
                value={formData.project}
                onChange={handleChange}
                placeholder="Project insight"
                required
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all"
              />

              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                placeholder="Message"
                rows={4}
                required
                className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/60 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all resize-none"
              />

              <motion.button
                type="submit"
                disabled={isSubmitting}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-full bg-white text-[#1152d4] py-4 rounded-2xl font-bold text-xl shadow-2xl hover:shadow-white/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <span className="flex items-center justify-center gap-2">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-[#1152d4] border-t-transparent rounded-full"
                    />
                    Sending...
                  </span>
                ) : (
                  'Get In Touch'
                )}
              </motion.button>
            </motion.form>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer({ scrollToSection }: any) {
  const socialLinks = [
    { icon: 'linkedin', label: 'LinkedIn', url: '#' },
    { icon: 'github', label: 'GitHub', url: '#' },
    { icon: 'mail', label: 'Email', url: '#' },
  ];

  return (
    <footer className="border-t border-[#1e293b] py-12 px-6">
      <div className="max-w-[375px] mx-auto text-center">
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-6"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <span className="material-icons text-[#1152d4]">security</span>
            <span className="font-bold">O. Sultan Oluwatobi</span>
          </div>
          <p className="text-[#94a3b8] text-sm">
            © 2024 Sultan Oluwatobi. All rights reserved.
          </p>
        </motion.div>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="flex justify-center gap-6"
        >
          {socialLinks.map((link, index) => (
            <motion.a
              key={link.label}
              href={link.url}
              whileHover={{ scale: 1.2, y: -5 }}
              whileTap={{ scale: 0.9 }}
              className="text-[#64748b] hover:text-[#1152d4] transition-colors"
              aria-label={link.label}
            >
              {link.icon === 'mail' ? (
                <span className="material-icons">mail</span>
              ) : (
                <div className="w-5 h-5 bg-[#64748b] hover:bg-[#1152d4] rounded transition-colors" />
              )}
            </motion.a>
          ))}
        </motion.div>
      </div>
    </footer>
  );
}
